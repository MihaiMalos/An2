#pragma once

#include "Util.h"

float GenerareEcuatie(float x);

void Laborator2();