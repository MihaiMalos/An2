#include "Laborator2.h"

void Laborator2()
{
	vector<vector<int>> matrix;
	matrix = ReadMatrix<int>("inverseMatrixInput.txt");
}