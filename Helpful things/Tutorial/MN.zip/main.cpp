
#include "Laborator2.h"

int main()
{
	Laborator2();
	Laborator3();
	Laborator4();
}